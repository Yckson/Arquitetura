Caro professor (Pailebe pra os mais chegados),

Abra o projeto através do link: https://github.com/Yckson/Arquitetura/tree/main/Projetos/MIPS%20Ciclo%20%C3%9Anico
para poder ler o README.md formatadinho filé da Bahia.

Valeu pela atenção e boa sorte pra corrigir todos os trabalhos kkkkkk
Espero ter adiantado o trabalho um pouco.

Aluno: William Gabriel Y A Braga
